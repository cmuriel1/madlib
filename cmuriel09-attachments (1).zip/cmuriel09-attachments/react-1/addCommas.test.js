const addCommas = require("./addCommas");

describe("#addCommas", () => {
  test("it is a function", () => {
    expect(typeof addCommas).toBe("function");
  });
});

describe("#addCommas", () => {
  test('1234 should return "1,234"', () => {
    expect(addCommas(1234)).toBe("1,234");
  });

  test('1000000 should return "1,000,000"', () => {
    expect(addCommas(1000000)).toBe("1,000,000");
  });

  test('9876543210 should return "9,876,543,210"', () => {
    expect(addCommas(9876543210)).toBe("9,876,543,210");
  });

  test('6 should return "6"', () => {
    expect(addCommas(6)).toBe("6");
  });

  test('-10 should return "-10"', () => {
    expect(addCommas(-10)).toBe("-10");
  });

  test('-5678 should return "-5,678"', () => {
    expect(addCommas(-5678)).toBe("-5,678");
  });

  //Bonus cases
  test('Large negative number -1234567890 should return "-1,234,567,890"', () => {
    expect(addCommas(-1234567890)).toBe("-1,234,567,890");
  });

  test('Zero should return "0"', () => {
    expect(addCommas(0)).toBe("0");
  });
});