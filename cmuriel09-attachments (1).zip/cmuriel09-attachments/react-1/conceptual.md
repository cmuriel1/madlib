### Conceptual Exercise

- What is React? When and why would you use it?
React is a JavaScript library used for building user interfaces, especially for web applications. It's great for creating interactive UIs and managing complex state changes in applications. You'd use React when you want to build dynamic, responsive, and scalable web applications.

- What is Babel?
Babel is a tool used to convert (or transpile) modern JavaScript code into versions that are compatible with older browsers or environments. It helps developers write code using the latest JavaScript features without worrying too much about compatibility issues.

- What is JSX?
JSX is a syntax extension for JavaScript that allows developers to write HTML-like code within JavaScript. It's commonly used in React to describe what the UI should look like. JSX makes it easier to write and understand the structure of React components.

- How is a Component created in React?
A component in React can be created by defining a JavaScript function or a class that returns JSX (or React elements). These components can be reusable and represent a part of the UI.

- What are some differences between state and props?
State is internal to a component and can be changed within the component itself. Props (short for properties) are passed from a parent component and are immutable within the child component that receives them.

- What does "downward data flow" refer to in React?
It means that data is passed from parent components to child components through props. Changes to this data usually flow in a top-down manner, allowing a unidirectional flow of data within the application.

- What is a controlled component?
A controlled component is a form element in React whose value is controlled by React's state. The value of the component is set by state and any changes to it are handled by React.

- What is an uncontrolled component?
An uncontrolled component is a form element whose value is not directly controlled by React's state. Instead, the value is managed by the DOM itself, typically used with vanilla JavaScript or other libraries.

- What is the purpose of the `key` prop when rendering a list of components?
The `key` prop is used to give each element in a list a stable identity. It helps React identify which items have changed, been added, or been removed. This is crucial for efficient rendering and updating of lists.

- Why is using an array index a poor choice for a `key` prop when rendering a list of components?
Array indices can cause issues when items are added, removed, or reordered. Using indices as keys might not provide a stable identity for each item, leading to unexpected behavior in component re-renders.

- Describe useEffect. What use cases is it used for in React components?
`useEffect` is a hook in React that allows you to perform side effects in functional components. It's used for tasks like data fetching, subscriptions, or manually changing the DOM in response to component updates.

- What does useRef do? Does a change to a ref value cause a rerender of a component?
`useRef` creates a mutable reference object that persists across component renders. Changes to the value of a ref don't trigger a component rerender unless that change impacts something used within the component's render function.

- When would you use a ref? When wouldn't you use one?
Refs are useful for accessing DOM nodes or storing mutable values that persist between renders. They're handy for managing focus, animations, or integrating with third-party libraries. However, they should be avoided for managing component state or trying to replace the standard React data flow.

- What is a custom hook in React? When would you want to write one?
A custom hook is a JavaScript function that starts with "use" and can use other hooks internally. It allows you to extract and reuse stateful logic from components. You'd want to write one when you find yourself repeating certain logic or when you want to share stateful logic between different components.
