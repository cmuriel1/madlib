import React, { useState } from 'react';
import './App.css';

const App = () => {
  const [formData, setFormData] = useState({
    noun: '',
    noun2: '',
    adjective: '',
    color: ''
  });
  const [displayStory, setDisplayStory] = useState('');
  const [selectedStory, setSelectedStory] = useState('story1'); // Initial story selection

  const stories = {
    story1: () => `The ${formData.noun} jumped over the ${formData.adjective} ${formData.noun2} while it was ${formData.color}.`,
    story2: () => `The ${formData.adjective} ${formData.noun} looked at the ${formData.color} sky and saw a ${formData.noun2}.`
    // Add more stories if needed
  };


  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const generateStory = stories[selectedStory];
    setDisplayStory(generateStory());
  };

  const handleRestart = () => {
    setDisplayStory('');
    setFormData({
      noun: '',
      noun2: '',
      adjective: '',
      color: ''
    });
  };

  return (
    <div>
      <select value={selectedStory} onChange={(e) => setSelectedStory(e.target.value)}>
        <option value="story1">Story 1</option>
        <option value="story2">Story 2</option>
      </select>

      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="noun">Noun:</label>
          <input type="text" name="noun" value={formData.noun} onChange={handleInputChange} required />
        </div>
        <div>
          <label htmlFor="noun2">Another Noun:</label>
          <input type="text" name="noun2" value={formData.noun2} onChange={handleInputChange} required />
        </div>
        <div>
          <label htmlFor="adjective">Adjective:</label>
          <input type="text" name="adjective" value={formData.adjective} onChange={handleInputChange} required />
        </div>
        <div>
          <label htmlFor="color">Color:</label>
          <input type="text" name="color" value={formData.color} onChange={handleInputChange} required />
        </div>
        
        <button type="submit">Generate Story</button>
      </form>

      {displayStory && (
        <div>
          <p>{displayStory}</p>
          <button onClick={handleRestart}>Restart</button>
        </div>
      )}
    </div>
  );
};

export default App;
